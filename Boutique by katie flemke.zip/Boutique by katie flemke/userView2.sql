- userView2.sql
-- User View 2: Customer Information View
SELECT custID, custName, custEmail, custPhone FROM Customer;
