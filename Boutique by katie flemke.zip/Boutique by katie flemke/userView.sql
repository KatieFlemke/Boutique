- userView1.sql
-- User View 1: Product Inventory View
SELECT prodID, prodDesc, unitPrice, quantOnHand FROM Product;
