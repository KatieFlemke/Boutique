-- Product Inventory Table
CREATE TABLE Product (
   -- create_tables.sql
-- Table creation statements for Vintage Designer Boutique Database Project

-- Product Inventory Table
CREATE TABLE Product (
    prodID INT PRIMARY KEY,
    prodDesc VARCHAR(100),
    designer VARCHAR(50),
    year INT,
    material VARCHAR(50),
    color VARCHAR(20),
    unitPrice DECIMAL(10, 2),
    quantOnHand INT
);

-- Insert into Product Inventory Table
INSERT INTO Product (prodID, prodDesc, designer, year, material, color, unitPrice, quantOnHand) VALUES
(1, 'Vintage Dress', 'Designer A', 1950, 'Silk', 'Red', 150.00, 10),
(2, 'Designer Handbag', 'Designer B', 1980, 'Leather', 'Black', 200.00, 5),
(3, 'Vintage Jewelry Set', 'Designer C', 1965, 'Gold', 'Gold', 100.00, 8);

);

-- Customer Information Table
CREATE TABLE Customer (
    custID INT PRIMARY KEY,
    custName VARCHAR(50),
    custEmail VARCHAR(50),
    custPhone VARCHAR(15),
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Sales Transactions Table
CREATE TABLE Sales (
    transactionID INT PRIMARY KEY,
    prodID INT,
    custID INT,
    transactionDate DATE,
    quantity INT,
    totalAmount DECIMAL(10, 2),
    FOREIGN KEY (prodID) REFERENCES Product(prodID),
    FOREIGN KEY (custID) REFERENCES Customer(custID)
);

-- Supplier Information Table
CREATE TABLE Supplier (
    supplierID INT PRIMARY KEY,
    supplierName VARCHAR(50),
    supplierContact VARCHAR(50),
    supplierEmail VARCHAR(50),
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Employee Management Table
CREATE TABLE Employee (
    empID INT PRIMARY KEY,
    empName VARCHAR(50),
    empRole VARCHAR(50),
    empSalary DECIMAL(10, 2),
    hireDate DATE,
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Financial Reports Table
CREATE TABLE FinancialReport (
    reportID INT PRIMARY KEY,
    reportDate DATE,
    totalSales DECIMAL(10, 2),
    totalExpenses DECIMAL(10, 2),
    netProfit DECIMAL(10, 2),
    city VARCHAR(50),
    country VARCHAR(50)
);
-- Sample data insertion statements for Vintage Designer Boutique Database Project

-- Insert into Product Inventory Table
INSERT INTO Product (prodID, prodDesc, designer, year, material, color, unitPrice, quantOnHand) VALUES
(1, 'Vintage Dress', 'Designer A', 1950, 'Silk', 'Red', 150.00, 10),
(2, 'Designer Handbag', 'Designer B', 1980, 'Leather', 'Black', 200.00, 5),
(3, 'Vintage Jewelry Set', 'Designer C', 1965, 'Gold', 'Gold', 100.00, 8),
(4, 'Classic Trench Coat', 'Designer D', 1972, 'Cotton', 'Beige', 250.00, 3),
(5, 'Retro Sunglasses', 'Designer E', 1960, 'Plastic', 'Tortoiseshell', 80.00, 12),
(6, 'Luxury Watch', 'Designer F', 1995, 'Stainless Steel', 'Silver', 500.00, 7),
(7, 'Vintage Scarf', 'Designer G', 1958, 'Silk', 'Printed', 120.00, 6);

-- Insert into Customer Information Table
INSERT INTO Customer (custID, custName, custEmail, custPhone, city, country) VALUES
(1, 'Alice Johnson', 'alice@example.com', '123-456-7890', 'New York', 'USA'),
(2, 'Bob Smith', 'bob@example.com', '987-654-3210', 'Los Angeles', 'USA');

-- Insert into Sales Transactions Table
INSERT INTO Sales (transactionID, prodID, custID, transactionDate, quantity, totalAmount) VALUES
(1, 1, 1, '2024-05-01', 2, 300.00),
(2, 2, 2, '2024-05-02', 1, 200.00);

-- Insert into Supplier Information Table
INSERT INTO Supplier (supplierID, supplierName, supplierContact, supplierEmail, city, country) VALUES
(1, 'Vintage Supplier', 'John Doe', 'supplier@example.com', 'London', 'UK');

-- Insert into Employee Management Table
INSERT INTO Employee (empID, empName, empRole, empSalary, hireDate, city, country) VALUES
(1, 'Jane Smith', 'Manager', 50000.00, '2020-01-01', 'Paris', 'France'),
(2, 'John Doe', 'Sales Associate', 30000.00, '2021-03-15', 'Rome', 'Italy');

-- Insert into Financial Reports Table
INSERT INTO FinancialReport (reportID, reportDate, totalSales, totalExpenses, netProfit, city, country) VALUES
(1, '2024-05-01', 1000.00, 500.00, 500.00, 'New York', 'USA'),
(2, '2024-05-02', 1500.00, 600.00, 900.00, 'Los Angeles', 'USA');
-- userView1.sql
-- User View 1: Product Inventory View
SELECT prodID, prodDesc, unitPrice, quantOnHand FROM Product;

-- userView2.sql
-- User View 2: Customer Information View
SELECT custID, custName, custEmail, custPhone FROM Customer;

-- userView3.sql
-- User View 3: Sales Transactions View
SELECT s.transactionID, p.prodDesc, c.custName, s.transactionDate, s.quantity, s.totalAmount
FROM Sales s
JOIN Product p ON s.prodID = p.prodID
JOIN Customer c ON s.custID = c.custID;

-- userView4.sql
-- User View 4: Supplier Information View
SELECT * FROM Supplier;

-- userView5.sql
-- User View 5: Employee Management View
SELECT * FROM Employee;

-- userView6.sql
-- User View 6: Financial Reports View
SELECT * FROM FinancialReport;