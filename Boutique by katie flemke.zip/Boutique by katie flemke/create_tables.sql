-- Product Inventory Table
CREATE TABLE Product (
   -- create_tables.sql
-- Table creation statements for Vintage Designer Boutique Database Project

-- Product Inventory Table
CREATE TABLE Product (
    prodID INT PRIMARY KEY,
    prodDesc VARCHAR(100),
    designer VARCHAR(50),
    year INT,
    material VARCHAR(50),
    color VARCHAR(20),
    unitPrice DECIMAL(10, 2),
    quantOnHand INT
);

-- Insert into Product Inventory Table
INSERT INTO Product (prodID, prodDesc, designer, year, material, color, unitPrice, quantOnHand) VALUES
(1, 'Vintage Dress', 'Designer A', 1950, 'Silk', 'Red', 150.00, 10),
(2, 'Designer Handbag', 'Designer B', 1980, 'Leather', 'Black', 200.00, 5),
(3, 'Vintage Jewelry Set', 'Designer C', 1965, 'Gold', 'Gold', 100.00, 8);

);

-- Customer Information Table
CREATE TABLE Customer (
    custID INT PRIMARY KEY,
    custName VARCHAR(50),
    custEmail VARCHAR(50),
    custPhone VARCHAR(15),
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Sales Transactions Table
CREATE TABLE Sales (
    transactionID INT PRIMARY KEY,
    prodID INT,
    custID INT,
    transactionDate DATE,
    quantity INT,
    totalAmount DECIMAL(10, 2),
    FOREIGN KEY (prodID) REFERENCES Product(prodID),
    FOREIGN KEY (custID) REFERENCES Customer(custID)
);

-- Supplier Information Table
CREATE TABLE Supplier (
    supplierID INT PRIMARY KEY,
    supplierName VARCHAR(50),
    supplierContact VARCHAR(50),
    supplierEmail VARCHAR(50),
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Employee Management Table
CREATE TABLE Employee (
    empID INT PRIMARY KEY,
    empName VARCHAR(50),
    empRole VARCHAR(50),
    empSalary DECIMAL(10, 2),
    hireDate DATE,
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Financial Reports Table
CREATE TABLE FinancialReport (
    reportID INT PRIMARY KEY,
    reportDate DATE,
    totalSales DECIMAL(10, 2),
    totalExpenses DECIMAL(10, 2),
    netProfit DECIMAL(10, 2),
    city VARCHAR(50),
    country VARCHAR(50)
);
